import socket              # 导入socket模块，用于网络通信
import sys                 # 导入sys模块，用于处理命令行参数和程序退出
import struct              # 导入struct模块，用于打包和解包二进制数据
import random              # 导入random模块，用于生成随机数

# 定义协议中报文的类型常量
TYPE_INIT = 1              # 初始化报文类型
TYPE_AGREE = 2             # 同意报文类型
TYPE_REQUEST = 3           # 请求报文类型
TYPE_RESPONSE = 4          # 响应报文类型

# 从文件读取文本，并随机分割成多个块，块大小介于Lmin和Lmax之间
def read_file_chunks(filename, Lmin, Lmax):
    with open(filename, 'r', encoding='utf-8') as f:   # 打开输入文件，使用utf-8编码读取文本
        text = f.read()                                # 读取整个文件内容为字符串
    i = 0                                              # 初始化索引i，表示当前读取位置
    chunks = []                                        # 用于存储分割后的文本块的列表
    while i < len(text):                               # 循环直到读取完整个文本
        length = random.randint(Lmin, Lmax)            # 随机生成当前块的长度，范围为Lmin到Lmax
        chunk = text[i:i+length]                        # 截取文本的这一段作为一个块
        chunks.append(chunk)                            # 将块加入列表
        i += length                                    # 更新索引，移动到下一个块的起点
    return chunks                                      # 返回所有文本块组成的列表

# 向服务器发送初始化报文，告诉服务器要发送多少个文本块
def send_init(sock, N):                                 #!表示使用网络字节序,B表示一个无符号字节,I表示一个无符号整数
    msg = struct.pack('!BI', TYPE_INIT, N)            # 按照网络字节序打包：1字节类型 + 4字节无符号整数N
    sock.sendall(msg)                                  # 发送初始化报文给服务器
    print(f"[Client] Sending Initialization: {N} blocks")  # 控制台打印发送信息

# 接收服务器的同意报文，确认服务器已准备好接收数据
def recv_agree(sock):
    data = sock.recv(1)                                # 接收1字节数据
    if data and data[0] == TYPE_AGREE:                 # 判断收到的数据是否是同意类型
        print("[Client] Received Agree from server.")  # 打印收到同意信息
    else:
        print("[Client] Did not receive proper Agree.")  # 如果没收到正确的同意报文，打印错误信息
        sys.exit(1)                                    # 退出程序，返回错误状态码1

# 向服务器发送请求报文，包含文本块的内容
def send_request(sock, data):
    encoded = data.encode('utf-8')                      # 将文本块编码成utf-8字节序列
    msg = struct.pack('!BI', TYPE_REQUEST, len(encoded)) + encoded  # 打包类型和长度后，拼接数据内容
    sock.sendall(msg)                                    # 发送请求报文

# 接收服务器的响应报文，获取服务器返回的反转字符串
def recv_response(sock):
    header = sock.recv(5)                                # 先接收报文头部：1字节类型 + 4字节长度
    if not header:                                       # 如果未收到头部数据，返回空字符串
        return ''
    type_, length = struct.unpack('!BI', header)        # 解包得到类型和数据长度
    if type_ != TYPE_RESPONSE:                           # 如果类型不是响应报文，打印错误
        print("Error: invalid response type.")
        return ''
    data = b''                                           # 初始化空字节串，用于累积接收数据
    while len(data) < length:                            # 循环接收，直到收到规定长度数据
        chunk = sock.recv(length - len(data))           # 接收剩余长度的数据
        if not chunk:                                    # 如果连接关闭或数据接收失败，退出循环
            break
        data += chunk                                    # 累积接收到的数据
    return data.decode('utf-8')                          # 将接收到的字节数据解码成字符串返回

def main():
    if len(sys.argv) != 6:                               # 判断命令行参数数量是否正确
        print("Usage: python client.py <server_ip> <server_port> <input_file> <Lmin> <Lmax>")  # 打印用法提示
        return                                          # 退出程序

    server_ip = sys.argv[1]                              # 获取服务器IP地址参数
    server_port = int(sys.argv[2])                       # 获取服务器端口号参数，转换为整数
    input_file = sys.argv[3]                             # 获取输入文件名参数
    Lmin = int(sys.argv[4])                              # 获取最小块长度参数，转换为整数
    Lmax = int(sys.argv[5])                              # 获取最大块长度参数，转换为整数

    chunks = read_file_chunks(input_file, Lmin, Lmax)   # 调用函数读取并分割文件文本为多个块
    N = len(chunks)                                      # 统计文本块数量

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建一个TCP套接字
    sock.connect((server_ip, server_port))               # 连接到服务器指定的IP和端口

    send_init(sock, N)                                   # 发送初始化报文给服务器，告知块数
    recv_agree(sock)                                     # 接收服务器同意报文，确认准备好接收

    reversed_chunks = []                                 # 用于保存服务器返回的反转文本块列表
    for idx, chunk in enumerate(chunks):                 # 遍历所有文本块及其索引
        send_request(sock, chunk)                        # 发送请求报文，包含当前文本块
        reversed_data = recv_response(sock)             # 接收服务器响应，获取反转文本
        print(f"[Client] Block {idx+1}: {reversed_data}")  # 打印当前块的反转结果
        reversed_chunks.append(reversed_data)            # 将反转结果加入列表

    # 把所有反转块倒序拼接成完整的反转文本
    full_reversed = ''.join(reversed_chunks[::-1])       # 注意切片[::-1]实现倒序拼接
    with open('reversed_output.txt', 'w', encoding='utf-8') as f:  # 打开输出文件，写入完整反转文本
        f.write(full_reversed)                            # 写文件
    print("[Client] Full reversed text written to reversed_output.txt")  # 提示写文件完成

    sock.close()                                         # 关闭与服务器的连接

if __name__ == '__main__':                               # 如果当前脚本是主程序执行入口
    main()                                              # 调用主函数执行客户端逻辑
