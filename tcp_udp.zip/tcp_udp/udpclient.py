import socket                          # 导入socket库，用于网络通信
import struct                          # 导入struct库，用于二进制数据打包和解包
import sys                             # 导入sys库，处理命令行参数
import time                            # 导入time库，用于计时
import pandas as pd                    # 导入pandas库，用于统计RTT指标计算

SERVER_IP = sys.argv[1]                # 从命令行参数获取服务器IP地址
SERVER_PORT = int(sys.argv[2])         # 从命令行参数获取服务器端口号，转换为整数

WINDOW_SIZE_BYTES = 400                # 发送窗口大小，单位为字节，总共400字节窗口
PACKET_SIZE = 80                      # 每个数据包固定大小80字节
WINDOW_SIZE_PACKETS = WINDOW_SIZE_BYTES // PACKET_SIZE  # 计算窗口中最多允许多少个包，400/80=5个
TIMEOUT = 0.3                        # 设置套接字接收超时时间为300毫秒（秒为单位）

def generate_packets(data):            # 生成数据包函数，输入完整字符串data，输出分包列表
    packets = []                       # 初始化空列表，用于保存所有分包
    seq = 0                           # 初始化序列号，从0开始
    i = 0                             # 字符串读取索引起点
    while i < len(data):              # 循环直到所有数据全部分包完毕
        segment = data[i:i+PACKET_SIZE]       # 按固定大小切片数据段（最多80字节）
        header = struct.pack('!IH', seq, len(segment.encode()))  # 打包包头：序列号(4字节) + 数据长度(2字节)
        packet = header + segment.encode()   # 合成完整包：包头 + 数据体（字符串编码成字节）
        packets.append((seq, packet, segment))  # 以元组形式保存序号、完整包、数据字符串
        seq += 1                           # 序号递增1
        i += PACKET_SIZE                   # 指针向后移动80字节
    return packets                        # 返回生成的所有包列表

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)   # 创建UDP socket对象
    sock.settimeout(TIMEOUT)                                  # 设置接收超时为300ms

    with open("input.txt", 'r', encoding='utf-8') as f:       # 读取输入文件全部内容，默认utf-8编码
        raw_data = f.read().strip()                           # 去除首尾空白字符

    # 连接建立阶段，向服务器发送握手消息 "HELLO"
    sock.sendto(b'HELLO', (SERVER_IP, SERVER_PORT))          # 发送HELLO到服务器IP和端口
    try:
        data, _ = sock.recvfrom(1024)                        # 接收服务器响应，最大缓存1024字节
        if data != b'WELCOME':                               # 如果收到的不是欢迎信息，则连接失败
            print("Connection failed")
            return
        print("[Client] Connected to server.")               # 连接成功提示
    except socket.timeout:                                    # 超时未收到欢迎信息，连接超时
        print("Connection timeout.")
        return

    packets = generate_packets(raw_data)                      # 将原始数据分割成数据包列表
    base = 0                                                  # 发送窗口的起始序号，窗口左边界
    next_seq = 0                                              # 下一个准备发送的包的序号
    send_time = {}                                            # 记录每个包的发送时间，用于计算RTT
    acked = set()                                             # 已确认的包序号集合，防止重复确认
    rtt_list = []                                             # 保存每个包的RTT值，用于统计
    total_sent = 0                                            # 记录总共发送了多少包（包括重传）

    while base < len(packets):                                # 循环直到所有包被确认，窗口左边界未超过最后包
        # 发送窗口内尚未发送的包
        while next_seq < len(packets) and next_seq < base + WINDOW_SIZE_PACKETS:
            seq, pkt, segment = packets[next_seq]            # 取出当前包的序号、完整数据包和字符串内容
            sock.sendto(pkt, (SERVER_IP, SERVER_PORT))       # 发送数据包到服务器
            send_time[seq] = time.time()                      # 记录发送时间戳
            print(f"[Client] 发送第{seq}个包，字节范围: {seq*PACKET_SIZE}~{seq*PACKET_SIZE + len(segment)}")  # 打印发送日志
            next_seq += 1                                     # 下一个待发送包序号加1
            total_sent += 1                                   # 发送总数计数器加1

        try:
            # 循环接收服务器ACK确认包
            while True:
                ack_data, _ = sock.recvfrom(1024)             # 阻塞等待ACK，1024字节缓存
                ack_seq = struct.unpack('!I', ack_data)[0]   # 解包ACK序列号，4字节无符号整数
                if ack_seq in acked:                          # 若ACK已收到过，忽略重复ACK
                    continue
                rtt = (time.time() - send_time[ack_seq]) * 1000  # 计算RTT，单位ms
                rtt_list.append(rtt)                           # 保存RTT值
                print(f"[Client] 第{ack_seq}个包被确认，RTT = {rtt:.2f} ms")  # 打印ACK和RTT信息
                acked.add(ack_seq)                             # 标记该包为已确认

                # 只有确认窗口左边界包，才滑动窗口
                if ack_seq == base:
                    while base in acked:                       # 滑动窗口，base递增直到遇到未确认包
                        base += 1
        except socket.timeout:                                # 接收ACK超时，启动重传机制
            print(f"[Client] 超时，重传窗口从第{base}个包开始")   # 打印超时重传信息
            next_seq = base                                    # 重传窗口内包序号从base开始
            for i in range(base, min(base + WINDOW_SIZE_PACKETS, len(packets))):
                seq, pkt, segment = packets[i]                 # 取待重传包的信息
                sock.sendto(pkt, (SERVER_IP, SERVER_PORT))     # 重新发送该包
                send_time[seq] = time.time()                    # 更新时间戳，重传时间
                print(f"[Client] 重传第{seq}个包，字节范围: {seq*PACKET_SIZE}~{seq*PACKET_SIZE + len(segment)}")  # 打印重传日志

    # 传输完成后打印统计信息
    print("\n========== 传输完成 ==========")
    total_loss = total_sent - len(acked)                      # 计算丢包数 = 总发包数 - 确认包数
    loss_rate = total_loss / total_sent * 100                  # 丢包率百分比
    print(f"丢包率：{loss_rate:.2f}% ({total_loss}/{total_sent})")

    if rtt_list:                                              # 如果有RTT数据，则计算统计指标
        df = pd.Series(rtt_list)                              # pandas序列方便计算统计量
        print(f"最大 RTT: {df.max():.2f} ms")
        print(f"最小 RTT: {df.min():.2f} ms")
        print(f"平均 RTT: {df.mean():.2f} ms")
        print(f"RTT 标准差: {df.std():.2f} ms")

if __name__ == '__main__':                                    # 脚本入口检查
    if len(sys.argv) != 3:                                    # 确保传入服务器IP和端口两个参数
        print("Usage: python udpclient.py <server_ip> <server_port>")
        sys.exit(1)
    main()                                                   # 执行主函数
