import socket  # 导入 socket 模块，用于创建 UDP 套接字进行通信
import struct  # 导入 struct 模块，用于将数据打包成二进制格式或从中解包
import random  # 导入 random 模块，用于生成随机数模拟丢包
import time  # 导入 time 模块，用于获取当前时间戳显示日志时间

# 配置服务器监听的地址和端口
SERVER_IP = '0.0.0.0'  # 监听本地所有可用网络接口
SERVER_PORT = 9999  # 设置UDP服务器端口
LOSS_PROB = 0.3  # 设置丢包概率为 30%

# 定义一个字典，用于记录每个序号的接收次数（模拟重传次数）
recv_count = {}


def current_time():
    """返回格式化的当前时间字符串，用于日志输出"""
    return time.strftime("%H:%M:%S", time.localtime())


def main():
    # 创建 UDP 套接字
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # 将套接字绑定到指定的 IP 和端口
    sock.bind((SERVER_IP, SERVER_PORT))

    # 打印服务器启动提示
    print(f"[{current_time()}] [Server] Listening on {SERVER_IP}:{SERVER_PORT}")

    # 不断循环，接收来自客户端的消息
    while True:
        # 接收数据和客户端地址（最多接收1024字节）
        data, addr = sock.recvfrom(1024)

        # 如果收到的是连接建立的消息 "HELLO"
        if data == b'HELLO':
            # 发送欢迎消息给客户端，建立连接
            sock.sendto(b'WELCOME', addr)
            print(f"[{current_time()}] [Server] Connection established with {addr}")
            continue  # 跳过本轮，等待下一次接收数据

        # 正常数据包结构：前6字节为自定义头部（4字节序号 + 2字节内容长度）
        seq_num, length = struct.unpack('!IH', data[:6])  # 解包序号和数据长度
        content = data[6:6 + length].decode(errors='ignore')  # 解码正文内容部分

        # 记录该序号的数据包已经被接收的次数（用于显示“第几次尝试”）
        if seq_num not in recv_count:
            recv_count[seq_num] = 1  # 第一次接收
        else:
            recv_count[seq_num] += 1  # 又一次尝试（重传）

        # 分隔每个包的输出
        print("\n------------------------------------------------------------")
        print(f"[{current_time()}] [Server] 收到数据包 seq={seq_num}（第 {recv_count[seq_num]} 次尝试）")

        # 模拟丢包：如果随机值小于丢包概率，则“丢弃”这个包，不发送 ACK
        if random.random() < LOSS_PROB:
            print(f"[{current_time()}] [Server] ❌ 丢弃包 seq={seq_num}")
            print(f"[内容预览] {content[:60]}{'...' if len(content) > 60 else ''}")  # 打印内容的前60个字符
            continue  # 丢包，不继续发送 ACK

        # 如果没有被丢包，视为成功接收该包
        print(f"[{current_time()}] [Server] ✅ 成功接收包 seq={seq_num}")
        print(f"[内容预览] {content[:60]}{'...' if len(content) > 60 else ''}")  # 打印内容的前60个字符

        # 构造 ACK 报文：仅发送 4 字节序号作为确认
        ack = struct.pack('!I', seq_num)
        sock.sendto(ack, addr)  # 发送 ACK 到客户端
        print(f"[{current_time()}] [Server] 发送 ACK seq={seq_num}")


# 如果该文件作为主程序运行（而不是被导入模块），则执行 main 函数
if __name__ == '__main__':
    main()
