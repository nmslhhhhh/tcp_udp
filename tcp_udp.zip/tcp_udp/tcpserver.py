import socket
import struct
import threading

TYPE_INIT = 1
TYPE_AGREE = 2
TYPE_REQUEST = 3
TYPE_RESPONSE = 4

def handle_client(conn,addr):   #conn这是和客户端通信的通道,addr是客户端的IP和端口
    print(f"[Server] Connection from {addr}")   #打印来自哪个客户端
    try:
        #接受客户端发来的Initialization报文
        init_msg = conn.recv(5)  #从客户端接收初始化报文
        if not init_msg:    #没收到数据,直接返回
            return

        #解析初始化报文
        type_, N = struct.unpack('!BI',init_msg)    #!表示网络字节序,B=1字节无符号,I=4字节无符号整数 type_报文类型,N是要发 几段文字
        if type_ != TYPE_INIT:  #如果不是初始化,输出错误
            print("[Server] Invalid init type")
            return

        #回复Agree报文,表示已准备好接收数据
        conn.sendall(struct.pack('!B',TYPE_AGREE))  #回复1字节类型字段(TYPE AGREE)

        #进入循环,接收N个数据块
        for _ in range(N):

            header = conn.recv(5)   #先读取头部: 类型(1字节) + 数据长度(4字节)
            if not header:
                break   #如果读取失败,退出循环

            type_, length = struct.unpack('!BI',header) #解析头部,获取类型和数据长度
            if type_ != TYPE_REQUEST: #如果类型不是请求类型,打印错误
                print("[Server] Invalid request type")
                break

            #接收指定长度的数据内容
            data = b''
            while len(data) < length:   #循环直到接收完完整长度的数据
                chunk = conn.recv(length - len(data))     #接收剩余长度的数据
                if not chunk:           #如果中途断开
                    break
                data += chunk           #累加接收剩余的数据
            #将接收到的数据变成字符串
            text = data.decode('utf-8') #UTF-8
            reversed_text = text[::-1]  #字符串反转操作!!
            encoded = reversed_text.encode('utf-8') #将反转后的字符串重新编码为字节

            #构造响应报文: 类型+数据长度+数据内容
            response = struct.pack('!BI',TYPE_RESPONSE,len(encoded)) + encoded
            conn.sendall(response)  #发送响应给客户端

    except Exception as e:      #捕获异常
        print(f"[Server] Error:{e}")    #打印错误信息

    finally:
        conn.close()    #关闭连接
        print(f"[Server] Disconnected {addr}")  #打印客户端断开信息

#主函数,启动TCP
def main():
    host = '0.0.0.0'  # 绑定所有可用IP(接收任意客户端
    port = 9999  # 监听端口号

    # 创建 TCP socket
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # 绑定地址与端口
    server_sock.bind((host, port))

    # 启动监听，最多允许5个排队连接
    server_sock.listen(5)
    print(f"[Server] Listening on port {port}")  # 打印监听信息

    # 循环接收新的客户端连接
    while True:
        conn, addr = server_sock.accept()  # 接受新的客户端连接
        thread = threading.Thread(target=handle_client, args=(conn, addr))  # 为每个客户端开一个线程
        thread.start()
        # 启动线程处理该客户端

# 程序入口
if __name__ == '__main__':
    main()

